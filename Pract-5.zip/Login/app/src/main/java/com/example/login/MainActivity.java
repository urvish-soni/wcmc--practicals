package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText Username;
    EditText Password;
    int count=3;
    Button button_login;
    TextView Register;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DatabaseHelper(this);
        Username = (EditText)findViewById(R.id.Username);
        Password = (EditText)findViewById(R.id.Password);
        button_login = (Button)findViewById(R.id.button_login);
        Register = (TextView)findViewById(R.id.Register);

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent register = new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(register);
            }
        });

        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = Username.getText().toString()
                        .trim();
                String pass = Password.getText().toString().trim();
                TextView incorrect;
                TextView attempts = (TextView)findViewById(R.id.textView2);
                TextView lim = (TextView)findViewById(R.id.textView3);
                Button logbtn;
                Button closeapp = (Button)findViewById(R.id.closeapp);
                Boolean res = db.checkUser(user,pass);
                if(res==true){
                    Toast toast = Toast.makeText(MainActivity.this,"Successfully logged in :)",Toast.LENGTH_SHORT);
                    view =toast.getView();
                    view.setBackgroundColor(Color.rgb(0,170,0));
                    TextView toastMessage = (TextView) toast.getView().findViewById(android.R.id.message);
                    toastMessage.setTextColor(Color.BLACK);
                    toast.show();
                } else {
                    lim.setVisibility(View.VISIBLE);
                    attempts.setVisibility(View.VISIBLE);
                    lim.setBackgroundColor(Color.RED);
                    count--;
                    lim.setText(Integer.toString(count));
                    incorrect = (TextView)findViewById(R.id.incorrect);
                    incorrect.setVisibility(View.VISIBLE);
                    if(count==0){
                        logbtn = (Button)findViewById(R.id.button_login);
                        logbtn.setText("Disabled");
                        logbtn.setEnabled(false);
                    }
                    closeapp.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            finish();
                            System.exit(0);
                        }
                    });
                }
            }
        });


    }
}
