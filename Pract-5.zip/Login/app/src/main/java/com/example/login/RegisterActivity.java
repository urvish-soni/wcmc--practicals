package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    DatabaseHelper db;
    EditText Username;
    EditText Password;
    EditText Cnf_Password;
    Button Register;
    TextView ViewLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        db = new DatabaseHelper(this);
        Username = (EditText)findViewById(R.id.Username);
        Password = (EditText)findViewById(R.id.Password);
        Cnf_Password = (EditText)findViewById(R.id.Cnf_Password);
        Register = (Button)findViewById(R.id.button_register);
        ViewLogin = (TextView)findViewById(R.id.Login);

        ViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login = new Intent(RegisterActivity.this,MainActivity.class);
                startActivity(login);
            }
        });
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = Username.getText().toString()
                        .trim();
                String pass = Password.getText().toString().trim();
                String cnf_pass = Cnf_Password.getText().toString().trim();

                if(pass.equals(cnf_pass)){
                    Long val = db.addUser(user,pass);
                    if(val>0){
                        Toast.makeText(RegisterActivity.this,"Registration successful",Toast.LENGTH_SHORT).show();
                        Intent movToLogin = new Intent(RegisterActivity.this,MainActivity.class);
                        startActivity(movToLogin);
                    } else {
                        Toast.makeText(RegisterActivity.this,"Register error!!",Toast.LENGTH_SHORT).show();
                    }


                } else {
                    Toast.makeText(RegisterActivity.this,"Password is not matching",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
